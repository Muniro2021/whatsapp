part of 'view_profile_screen_cubit.dart';

@immutable
abstract class ViewProfileScreenState {}

class ViewProfileScreenInitial extends ViewProfileScreenState {}
