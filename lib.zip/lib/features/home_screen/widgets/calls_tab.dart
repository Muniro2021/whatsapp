import 'package:flutter/material.dart';

class LeavesTab extends StatelessWidget {
  const LeavesTab({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}