import 'package:flutter/material.dart';

class CallsTab extends StatelessWidget {
  const CallsTab({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}